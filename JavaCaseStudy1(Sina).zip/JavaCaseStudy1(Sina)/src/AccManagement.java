//import java.util.Scanner;
//import  java.util.Random;
//
//public class AccManagement {
//	// TODO Auto-generated method stub
//			Scanner sc = new Scanner(System.in);
//			Random rand = new Random();
//			public static int count = 0;
////			String adId = "Admin154";
////			String adPass = "Admin@154";
//			
//			public void Management() {
//				Account[] arr = new Account[50];
//				int choice;
//				int max = 10000, min = 1000;
//				do {
//					System.out.println("Enter Your Choice:\n1.Login as Admin\n2.Login as User\n3.Open Account\n0.Exit");
//					choice = sc.nextInt();
//					if(choice==1) {
//						String id,pass;
//						System.out.println("Enter Your Admin ID : ");
//						sc.nextLine();
//						id = sc.nextLine();
//						if(id.equals("Admin154")) {
//							System.out.println("Enter Your Password : ");
//							pass = sc.nextLine();
//							if(pass.equals("Admin@154")) {
//								System.out.println("\nEnter Your Choice:\n1.Display All Account Details\n2.Daily Report\n0.Logout");
//								int choice1 = sc.nextInt();
//								do {
//									if(choice1==0) {
//										break;
//									//logout
//									}
//									else if(choice1 == 1){
//										//Method Display All Account Details
//										for(int i=0;i<count;i++) {
//											
//										}
//									}
//									else if(choice1 == 2) {
//										//Method Daily Report
//									}
//									else {
//										System.out.println("You Enter Wrong Choice!\n");
//									}
//								}while(choice1!=0);
//								
//							}
//							else {
//								System.out.println("You Enter Wrong Password!\n");
//							}
//						}
//						else{
//							System.out.println("You Enter Wrong ID!\n");
//						}
//					}
//					else if(choice==2) {
//						System.out.println("Enter User id(Account Number) :");
//						int acc = sc.nextInt();
//						int flag=0;
//						for(int i=0;i<count;i++) {							
//							if(arr[i].getAccNo() == acc) {
//								//incomplete
//								flag=1;
//								max = 10000;
//								min = 1000;
//								int otp = rand.nextInt(max - min + 1) + min;
//								System.out.println("Captcha : " + otp);
//								System.out.println("Enter the Password: ");
//								int pass = sc.nextInt();
//								if(pass==otp) {
//									int ch;
//									do {
//										System.out.println("Enter Your Choice : \n1.Deposite\n2.Withdraw\n3.Calculate Interest\n4.Check Balance\n5.Transfer\n6.Close Account\n0.Logout");
//										ch=sc.nextInt();
//										if(ch==1) {
//											arr[i].Deposite();
//										}
//										else if(ch==2) {
//											arr[i].Withdraw();
//										}
//										else if(ch==3) {
//											arr[i].CalInterest();
//										}
//										else if(ch==4) {
//											arr[i].CheckBalance();;
//										}
//										else if(ch==5) {
//											//arr[i].Transfer();
//										}
////										else if(ch==2) {
////											arr[i].Withdraw();
////										}
////										else if(ch==2) {
////											arr[i].Withdraw();
////										}
////										else if(ch==2) {
////											arr[i].Withdraw();
////										}
//										
//									}while(ch!=0);
//									break;	
//								}
//								else {
//									System.out.println("You Entered Wrong OTP\n");
//								}
//							}
//						}
//						if(flag==0) {
//							System.out.println("You Entered Wrong User ID! Or You Cannot Open Account\n ");
//						}
//					}
//					else if(choice == 3) {     ///INCOMPLETE
//						
//						int accNo;
////						String opDate = "05/03/2023";
////						String accType;
//						double amt;
//						
//						System.out.println("Choose your Account Type:\n1.Saving Account\n2.Salary Account\n3.Current Account\n4.Loan Account");
//						int typeChoice = sc.nextInt();
//						
//						System.out.println("Enter Name: ");
//						sc.nextLine();
//						String hName = sc.nextLine();	
//						
//						System.out.println("Enter Amount to deposite: ");
//						amt=sc.nextDouble();
//						
//						if( typeChoice == 1) {
//							//accType = "Saving";
//							if(amt>10000) {							
//								max = 1000000;
//								min = 100000;
//								accNo = rand.nextInt(max - min + 1) + min;
//								arr[count++] = new SavingAcc(accNo,hName,amt);        // references of account is Created
//								//System.out.println(accNo);
//								//arr[count++] = A1;								//add reference in array
//								//System.out.println("count " + count)
//								System.out.println("Saving Account Created\nYour Account Information");
//								System.out.println(arr[count-1]);	
//								System.out.println("\n");
//							}
//							else {
//								System.out.println("Your Account Not Created you Deposite Amount Less Than 10K!\n");
//							}
//							//Account.setAccType("Saving");
//						}
//						else if(typeChoice == 2) {
//							//accType = "Salary";
//							//Account.setAccType(accType);
//						}
//						else if(typeChoice == 3) {
//							//accType = "Current";
//							//Account.setAccType(accType);
//						}
//						else if(typeChoice == 4) {
//							//accType = "Loan";
//							//Account.setAccType(accType);
//						}
//						else {
//							System.out.println("You Enter Wrong Choice!");
//						}
//						
//						
//					}
//					else if(choice == 0) {
//						System.out.println("*** THANK YOU ***");
//						break;
//					}
//					else {
//						System.out.println("You Enter Wrong Choice!\n");
//					}
//					
//				}while(choice!=0);
//			}
//			
//			
//}
