//                             Team Name = Sina
//Saving And Salary Account class Done  and some Managenment ideas given by Nilesh Hatkar
//Loan Class And user login Management part like withdraw check balance interest done by Aaditya Karkal
//Current account class and Admin part like Daily report (Transaction) done by saurabh Vanjari

//	String adId = "Admin154";
//	String adPass = "Admin@154";



import java.util.Random;
import Transaction;

import java.util.Scanner;
public class Main {
	
	static Random rand = new Random();
	public static int count = 0;
	public static int ctr = 0;
	static Scanner sc = new Scanner(System.in);
	static Account[] arr = new Account[50];
	static Transaction[] trr = new Transaction[15];

	
	public static void main(String[] args) {
			int choice;
			do {
				System.out.println("|---------------------------|");
				System.out.println("|   Bank Managamet System   |");
				System.out.println("|---------------------------|");
				System.out.println("|Enter Your Choice:         |");
				System.out.println("|---------------------------|");
				System.out.println("| 1. | Login as Admin       |");
				System.out.println("|---------------------------|");
				System.out.println("| 2. | Login as User        |");
				System.out.println("|---------------------------|");
				System.out.println("| 3. | Open Account         |");
				System.out.println("|---------------------------|");
				System.out.println("| 0. |   Exit               |");
				System.out.println("|---------------------------|");
				choice = sc.nextInt();
				if(choice==1) {
					AdminLogin();
				}
				else if(choice==2) {
					UserLogin();
				}
				else if(choice == 3) {     
					CreateAccount();	
				}
				else if(choice == 0) {
					System.out.println("*** THANK YOU ***");
					break;
				}
				else {
					System.out.println("You Enter Wrong Choice!\n");
				}
				
			}while(choice!=0);
		}
	
	public static int AccountNoGenerate() {
		int max = 1000000;
		int min = 100000;
		return rand.nextInt(max - min + 1) + min;
	}
	public static int OtpGenerate() {
		int max = 10000;
		int min = 1000;
		return rand.nextInt(max - min + 1) + min;
	}
	public static void AccountDetails() {
		if(count>0) {
			System.out.println(" *** Information of All Accounts *** ");
			for(int i=0;i<count;i++) {
				System.out.println("Account Number: " + arr[i].getAccNo() + "\nAccount Holder Name: " + arr[i].gethName() + "\n");
			}
		}
		else {
			System.out.println("No Account is Open\n");
		}	
	}
	
	public static void AdminLogin() {
		String id,pass;
		System.out.println("Enter Your Admin ID : ");
		sc.nextLine();
		id = sc.nextLine();
		if(id.equals("Admin154")) {
			System.out.println("Enter Your Password : ");
			pass = sc.nextLine();
			if(pass.equals("Admin@154")) {
				int choice1;
				do {
					System.out.println("             Admin User =   " + id);
					System.out.println("|------------------------------------|");
					System.out.println("| Enter Your Choice :                |");
					System.out.println("|------------------------------------|");
					System.out.println("| 1. | Display All Account Details   |");
					System.out.println("| 2. | Daily Report                  |");
					System.out.println("| 0. | Logout                        |");
					System.out.println("|------------------------------------|");
					choice1 = sc.nextInt();
					if(choice1==0) {
						break;
					//logout
					}
					else if(choice1 == 1){
						//Method Display All Account Details
						AccountDetails();
					}
					else if(choice1 == 2) {
						displayDailyReport();
						//Method Daily Report
					}
					else {
						System.out.println("You Enter Wrong Choice!\n");
					}
				}while(choice1!=0);
				
			}
			else {
				System.out.println("You Enter Wrong Password!\n");
			}
		}
		else{
			System.out.println("You Enter Wrong ID!\n");
		}
	}
	
	public static void UserLogin() {
		System.out.println("Enter User id(Account Number) :");
		int acc = sc.nextInt();
		int flag=0;
		for(int i=0;i<count;i++) {							
			if(arr[i].getAccNo() == acc) {
				//incomplete
				flag=1;
				int otp = OtpGenerate();
				System.out.println("Captcha : " + otp);
				System.out.println("Enter the Password: ");
				int pass = sc.nextInt();
				if(pass==otp) {
					int ch;
					do {
						System.out.println("                  User AccountNo =  " + acc);
						System.out.println("|---------------------------------------|");
						System.out.println("| Enter Your Choice :                   |");
						System.out.println("|---------------------------------------|");
						System.out.println("| 1. | Deposite                         |");
						System.out.println("| 2. | Withdraw                         |");
						System.out.println("| 3. | Calculate Interest               |");
						System.out.println("| 4. | Check Balance                    |");
						System.out.println("| 5. | Transfer                         |");
						System.out.println("| 6. | Close Account                    |");
						System.out.println("| 0. | Logout                           |");
						System.out.println("|---------------------------------------|");
					
						
						//System.out.println("Enter Your Choice : \n1.Deposite\n2.Withdraw\n3.Calculate Interest\n4.Check Balance\n5.Transfer\n6.Close Account\n0.Logout");
						ch=sc.nextInt();
						if(ch==1) {
							System.out.println("How Many Amount Do you want to deposite: ");
							double amt = sc.nextDouble();
							if(arr[i].Deposite(amt)) {
								System.out.println("jfgadnjgnek");
								trr[ctr++] = new Transaction(ctr,arr[i].getAccNo(),"Deposite",amt);
							}
						}
						else if(ch==2) {
							System.out.println("How Many Amount Do you want to Withdraw: ");
							double amt = sc.nextDouble();
							if(arr[i].Withdraw(amt)) {
								trr[ctr++] = new Transaction(ctr,arr[i].getAccNo(),"Withdraw",amt);
							}	
						}
						else if(ch==3) {
							arr[i].CalInterest();
						}
						else if(ch==4) {
							arr[i].CheckBalance();;
						}
//						else if(ch==5) {
//							arr[i].Transfer();
//						}
//						else if(ch==2) {
//							arr[i].Withdraw();
//						}
//						else if(ch==2) {
//							arr[i].Withdraw();
//						}
//						else if(ch==2) {
//							arr[i].Withdraw();
//						}
						
					}while(ch!=0);
					break;	
				}
				else {
					System.out.println("You Entered Wrong OTP\n");
				}
			}
		}
		if(flag==0) {
			System.out.println("You Entered Wrong User ID! Or You Cannot Open Account\n ");
		}
	}
	
	
	
	public static void CreateAccount() {
		int accNo;
//		String opDate = "05/03/2023";
//		String accType;
		double amt;
		System.out.println();
		System.out.println("|----------------------------|");
		System.out.println("|Choose your Account Type:   |");
		System.out.println("|----------------------------|");
		System.out.println("| 1. | Saving Account        |");
		System.out.println("| 2. | Salary Account        |");
		System.out.println("| 3. | Current Account       |");	
		System.out.println("| 4. | Loan Account          |");
		System.out.println("|----------------------------|");
		
		
		int typeChoice = sc.nextInt();
		
		System.out.println("Enter Name: ");
		sc.nextLine();
		String hName = sc.nextLine();	
		
		if( typeChoice == 1) {
			System.out.println("Enter Amount to deposite: ");
			amt=sc.nextDouble();
			//accType = "Saving";
			if(amt>10000) {							
				
				accNo = AccountNoGenerate();
				arr[count++] = new SavingAcc(accNo,hName,amt);        // references of account is Created
				//System.out.println(accNo);
				//arr[count++] = A1;								//add reference in array
				//System.out.println("count " + count)
				System.out.println("Saving Account Created\nYour Account Information");
				trr[ctr++] = new Transaction(ctr,arr[count-1].getAccNo(),"Saving Account Created",amt);
				System.out.println(arr[count-1]);	
				System.out.println("\n");
			}
			else {
				System.out.println("Your Account Not Created you Deposite Amount Less Than 10K!\n");
			}
			//Account.setAccType("Saving");
		}
		else if(typeChoice == 2) {
			System.out.println("Enter Amount to deposite: ");
			amt=sc.nextDouble();
			System.out.println("Enter Transaction date in format yyyy-mm-dd: ");
			sc.nextLine();
			String date = sc.nextLine();
			accNo = AccountNoGenerate();
			arr[count++] = new SalaryAcc(accNo,hName,amt,date);
			System.out.println("   Welcome to Our Bank   ");
			System.out.println("Your Salary Account Created\nYour Account Information");
			trr[ctr++] = new Transaction(ctr,arr[count-1].getAccNo(),"Salary Account Created",amt);
			System.out.println(arr[count-1]);	
			System.out.println("\n");
		}
		else if(typeChoice == 3) {
			System.out.println("Enter Amount to deposite: ");
			amt=sc.nextDouble();
			//accType = "Current";
			//Account.setAccType(accType);
			accNo = AccountNoGenerate();
			arr[count++] = new CurrentAcc(accNo,hName,amt);
			System.out.println("Current Account Created\nYour Account Information");
			trr[ctr++] = new Transaction(ctr,arr[count-1].getAccNo(),"Current Account Created",amt);
			System.out.println(arr[count-1]);	
			System.out.println("\n");
		}
		else if(typeChoice == 4) {
			accNo = AccountNoGenerate();
			arr[count++] = new LoanAcc(accNo,hName);
			System.out.println("Loan Account Created\nYour Account Information");
			trr[ctr++] = new Transaction(ctr,arr[count-1].getAccNo(),"Loan Account Created",0);
			System.out.println(arr[count-1]);	
			System.out.println("\n");
			//accType = "Loan";
			//Account.setAccType(accType);
		}
		else {
			System.out.println("You Enter Wrong Choice!");
		}
	}
	
	
//	public static Boolean Transfer() {
//	System.out.println("Enter Receeiver Account Number To Send Money : ");
//	int accNumber = sc.nextInt();
//	for(int i=0;i<count;i++) {
//		if(arr[i].getAccNo() != accNumber) {
//			System.out.println("Receiver Account Number Not Found or You Entered Wrong Account Number");
//			return false;
//		}
//		else {
//			System.out.println("Enter How Much Amount Do you want to transfer : ");
//			double amt = sc.nextDouble();
//			if(getBalance() > amt) {
//				
//			}
//			return true;
//		}
//	}
//	System.out.println("How Much Amount do you want to Send : ");
//}
	
	
	
	public static void displayDailyReport() {
		if(ctr>0) {
			System.out.println("--------------------------------------------------------------------");
			System.out.println("|  SrNo |  Account No  |        Process Name        |    Amount   |");
			for(int i=0;i<ctr;i++) {
				System.out.println("--------------------------------------------------------------------");
				System.out.println("|   " + trr[i].getSrNo() + "   |    " + trr[i].getAccNo() + "    |   " + trr[i].getProcessName() + "   |   " + trr[i]. getAmt() + "   |");
			}
			System.out.println("--------------------------------------------------------------------");	
		}
		else {
			System.out.println("No Transaction is done for today");
		}
	}
	
	
}
