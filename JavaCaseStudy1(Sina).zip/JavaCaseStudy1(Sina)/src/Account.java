import java.util.Date;
import java.util.Scanner;
abstract public class Account {
	int accNo;
	String hName;
//	String opDate;
//	String accType;
	double balance;
	Scanner sc = new Scanner(System.in);
	
	public Account(int accNo, String hName, double balance) {
		super();
		this.accNo = accNo;
		this.hName = hName;
//		this.opDate = opDate;
//		this.accType = accType;
		this.balance = balance;
	}
	
	
	public int getAccNo() {
		return this.accNo;
	}
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	public String gethName() {
		return hName;
	}
	public void sethName(String hName) {
		this.hName = hName;
	}
//	public String getOpDate() {
//		return this.opDate;
//	}
//	public void setOpDate(String opDate) {
//		this.opDate = opDate;
//	}
//	public String getAccType() {
//		return this.accType;
//	}
//	public void setAccType(String accType) {
//		this.accType = accType;
//	}
	public double getBalance() {
		return this.balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	
	
	abstract public boolean Deposite(double amt);
	abstract public boolean Withdraw(double amt);
	abstract public void CalInterest() ;
	abstract public void CheckBalance();
	
	
	
	public String toString() {
		
		return "accNo=" + this.accNo + ",\nhName=" + this.hName + ",\nbalance=" + this.balance ;
			
	}
	
	
}
