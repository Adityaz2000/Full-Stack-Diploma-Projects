
public class Transaction {
	 int srNo;
	 int accNo;
	 String processName;
	 double amt;
	 
	 
	 
	 
	 
	public Transaction(int srNo,int accNo, String processName, double amt) {
		super();
		this.accNo = accNo;
		this.processName = processName;
		this.amt = amt;
		this.srNo = srNo;
	}
	
	
	public int getSrNo() {
		return srNo;
	}
	public void setSrNo(int srNo) {
		this.srNo = srNo;
	}
	public int getAccNo() {
		return accNo;
	}
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	public String getProcessName() {
		return processName;
	}
	public void setProcessName(String processName) {
		this.processName = processName;
	}
	public double getAmt() {
		return amt;
	}
	public void setAmt(double amt) {
		this.amt = amt;
	}

	
	
	 
	
}
