
public class CurrentAcc extends Account{
	double overDraftLimit;
	double overDraftAmt;

	
	public CurrentAcc(int accNo, String hName, double balance) {
		super(accNo, hName, balance);
		overDraftAmt = 0;
		overDraftLimit = 50000;
		
		
		
		// TODO Auto-generated constructor stub
	}


	public double getOverDraftLimit() {
		return overDraftLimit;
	}
	
	public void setOverDraftLimit(double overDraftLimit) {
		this.overDraftLimit = overDraftLimit;
	}


	public double getOverDraftAmt() {
		return overDraftAmt;
	}


	public void setOverDraftAmt(double overDraftAmt) {
		this.overDraftAmt = overDraftAmt;
	}	
	
	public boolean Deposite(double amt) {
		if(overDraftAmt ==  0) {
			this.setBalance(this.getBalance() + amt);
			System.out.println("balance = " + this.getBalance() + "OverDraftAmt = " +  this.getOverDraftAmt() + "limit = " + this.getOverDraftLimit());
			System.out.println("Deposite Succefully");
			return true;
		}
		else {
			if(amt > overDraftAmt) {
				this.setBalance(amt - overDraftAmt);
				setOverDraftAmt(0);	
				System.out.println("balance = " + this.getBalance() + "OverDraftAmt = " + this.getOverDraftAmt() + "limit = " + this.getOverDraftLimit());
				System.out.println("Deposite Succefully\n");
				return true;
			}
			else {
				setOverDraftAmt(overDraftAmt - amt);
				System.out.println("balance = " + this.getBalance() + "OverDraftAmt = " + this.getOverDraftAmt() + "limit = " + this.getOverDraftLimit());
				System.out.println("Deposite Succefully\n");
				return true;
			}
		}
		
	}
	public boolean Withdraw(double amt) {
//		if(this.getBalance()>=amt) {
//			this.setBalance(this.getBalance() - amt);
//			System.out.println("1.Withdraw Succesfully!");
//			//System.out.println("balance = " + this.getBalance() + "OverDraftAmt = " +  this.getOverDraftAmt() + "limit = " + this.getOverDraftLimit());
//			return true;
//		}
//		else if(this.getBalance() + this.getOverDraftLimit() - this.getOverDraftAmt() >= amt){
//			this.setOverDraftAmt(this.getOverDraftAmt() + amt - this.getBalance());
//			this.setBalance(0);
//			System.out.println("2.Withdraw Succesfully!");
//			System.out.println("balance = " + this.getBalance() + "OverDraftAmt = " +  this.getOverDraftAmt() + "limit = " + this.getOverDraftLimit());
//			return true;
//		}
//		else {
//			System.out.println("balance = " + this.getBalance() + "OverDraftAmt = " +  this.getOverDraftAmt() + "limit = " + this.getOverDraftLimit());
//			System.out.println("3.You Only Withdraw ₹ " + (this.getOverDraftLimit() - this.getOverDraftAmt()));
//			return false;
//		}
		
		
		if(this.getBalance()>=amt) {
			this.setBalance(this.getBalance() - amt);
			System.out.println("1.Withdraw Succesfully!");
			System.out.println("balance = " + this.getBalance() + "OverDraftAmt = " +  this.getOverDraftAmt() + "limit = " + this.getOverDraftLimit());
		}
		else if(this.getBalance() + this.getOverDraftLimit() - this.getOverDraftAmt() >= amt){
			this.setOverDraftAmt(this.getOverDraftAmt() + amt - this.getBalance());
			this.setBalance(0);
			System.out.println("2.Withdraw Succesfully!");
			System.out.println("balance = " + this.getBalance() + "OverDraftAmt = " +  this.getOverDraftAmt() + "limit = " + this.getOverDraftLimit());
		}
		else {
			System.out.println("balance = " + this.getBalance() + "OverDraftAmt = " +  this.getOverDraftAmt() + "limit = " + this.getOverDraftLimit());
			System.out.println("3.You Only Withdraw ₹ " + (this.getOverDraftLimit() - this.getOverDraftAmt()));
		}
		return true;
	}
	
	
	public void CalInterest() {
		System.out.println("Your Account is Current Account Interest rate not For You!\n");
	}
	
	public void CheckBalance() {
		System.out.println("Your Balance is ₹ " + this.getBalance());
	}
	
	public void Transfer() {
		
	}
	
	
	
	public String toString() {
		String ps = super.toString();
		return ps;
		//return "accNo=" + accNo + ",\nhName=" + hName + ",\nopDate=" + opDate + ",\naccType=" + accType + ",\nbalance=" + balance ;
			
	}
	
	
	
	
}
