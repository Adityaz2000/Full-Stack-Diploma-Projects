module CaseStudyJava {
}